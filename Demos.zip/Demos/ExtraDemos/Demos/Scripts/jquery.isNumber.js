(function($) {
	$.isNumber = function(value) {
		var result = false;
		var regex=/^[0-9]+$/;
		if(regex.test(value))
		{
			result = true;
		}
		return result;
	};
})(jQuery);

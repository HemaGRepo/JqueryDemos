(function($) {
	$.fn.formCheck = function(options) {
		var defaults = {
			errorClass: "error"
		};
		
		var option = jQuery.extend(defaults, options);
		
		return this.each(function() {
			var form = $(this);
			if(!form.is ("form")) return;
		
			form.submit(function() {
				var errorFlag = false;
				$(":input", this).each(function(index, element) {
					e = $(element);
					e.removeClass(option.errorClass);
					if(e.hasClass("required") && e.val() == '') {
						errorFlag = true;
						e.addClass(option.errorClass);
					}
				});
				return !errorFlag; //To avoid submitting the Form
			});
		});
	};
})(jQuery);
	
	
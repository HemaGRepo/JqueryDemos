(function($) {
    $.fn.customTooltip = function(message) {
		return this.each(function() {
			this.title=message;
		});
	}
})(jQuery);




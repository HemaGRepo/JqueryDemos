$.fn.greenify = function() {
    this.css( "color", "green" );
};